//
//  ViewController.m
//  椭圆
//
//  Created by Han on 2017/6/29.
//  Copyright © 2017年 Han. All rights reserved.
//

#import "ViewController.h"
#import "UIButton+MyBtn.h"
@interface ViewController ()

@property (nonatomic, strong) NSMutableArray *btnArray;
@property (nonatomic,retain)NSTimer *tim;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    float x = 50;
    float y = 100;
    
    
    float a = 300;
    float b = 150;
    float r = 20;
    float c = 10;
    float s = 360/c;
    
    CAShapeLayer *layer1 = [CAShapeLayer layer];
    layer1.frame = CGRectMake(x, y, a, a);
    layer1.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, a, a) cornerRadius:a/2].CGPath;
    layer1.fillColor = [UIColor blueColor].CGColor;
    layer1.zPosition = 1;
    [self.view.layer addSublayer:layer1];
    
    CAShapeLayer *layer2 = [CAShapeLayer layer];
    layer2.frame = CGRectMake(x, y, a, a);
    layer2.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake((a - b)/2, (a - b)/2, b, b) cornerRadius:a/2].CGPath;
    layer2.fillColor = [UIColor redColor].CGColor;
    layer2.zPosition = 3;
    [self.view.layer addSublayer:layer2];
 
    _btnArray = [NSMutableArray arrayWithCapacity:0];
    
    for (int i = 0; i < c; i ++)
    {
        UIButton *btn = [[UIButton alloc] init];
        btn.bounds = CGRectMake(0, 0,r * 2, r * 2);
        btn.center = CGPointMake((x + a/2 + a/2 * cos(s * i * M_PI/180.0)), y +  a/2 - b/2 * sin(s * i * M_PI/180.0));
        btn.backgroundColor = [UIColor grayColor];
        [btn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        btn.layer.masksToBounds = YES;
        btn.tag = i + 1;
        btn.btnAngle = @(s * i);
        [btn zp];
        [btn changeSize];
        [btn setTitle:[NSString stringWithFormat:@"%ld",btn.tag] forState:UIControlStateNormal];
        [self.view.layer addSublayer:btn.layer];
        [self.view addSubview:btn];
        [_btnArray addObject:btn];
    }
    
}
- (void)btnClicked:(UIButton *)sender
{
    _tim=[NSTimer scheduledTimerWithTimeInterval:.03 target:self selector:@selector(changeSize:) userInfo:sender repeats:YES];
    self.view.userInteractionEnabled = NO;
}

- (void)changeSize:(NSTimer *)timer
{

    
    UIButton *btn1 = (UIButton *)[timer userInfo];
     if ([btn1.btnAngle floatValue] == 270)
    {
        self.view.userInteractionEnabled = YES;
        [_tim invalidate];
        _tim=nil;
        return;
    }
    
    
    float x = 50;
    float y = 100;
    float a = 300;
    float b = 150;
    
   
    for (UIButton *btn in _btnArray)
    {
        btn.btnAngle = [NSNumber numberWithFloat: [btn.btnAngle floatValue] + 6];
        int cx = x + a/2 + a/2 * cos([btn.btnAngle floatValue] * M_PI/180.0);
        int cy = y +  a/2 - b/2 * sin([btn.btnAngle floatValue] * M_PI/180.0);
        btn.center = CGPointMake(cx, cy);
        [btn zp];
        [btn changeSize];
        
        
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
